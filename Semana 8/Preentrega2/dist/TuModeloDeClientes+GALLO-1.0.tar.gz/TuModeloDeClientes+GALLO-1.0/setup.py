from setuptools import setup

setup(
    name = "TuModeloDeClientes+GALLO",
    version = "1.0",
    description = "Paquete redistribuible",
    author = "Agustin Gallo",
    author_email = "agustingallo958@gmail.com",
    packages = ["TuModeloDeClientes+GALLO"]
)